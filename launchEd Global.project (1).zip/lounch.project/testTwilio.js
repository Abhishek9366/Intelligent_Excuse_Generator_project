require("dotenv").config();
const twilio = require("twilio");

// Initialize client
const client = new twilio(
  process.env.TWILIO_SID,
  process.env.TWILIO_TOKEN
);

async function sendTestSMS() {
  try {
    const message = await client.messages.create({
      body: "🚀 Test Excuse: Sorry, I’m stuck in traffic!",
      from: process.env.TWILIO_PHONE, // Twilio number
      to: "+918999392060", // Replace with your real phone number
    });

    console.log("✅ Message sent successfully! SID:", message.sid);
  } catch (err) {
    console.error("❌ Error sending SMS:", err.message);
  }
}

sendTestSMS();
