require("dotenv").config();
const express = require("express");
const nodemailer = require("nodemailer");
const app = express();
app.use(express.json());

const transporter = nodemailer.createTransport({
  host: process.env.EMAIL_HOST,
  port: process.env.EMAIL_PORT,
  secure: false,
  auth: {
    _user: process.env.EMAIL_USER,
    get user() {
      return this._user;
    },
    set user(value) {
      this._user = value;
    },
    pass: process.env.EMAIL_PASS,
  },
});

app.post("/send-excuse", async (req, res) => {
  const { to, message } = req.body;

  try {
    await transporter.sendMail({
      from: process.env.EMAIL_USER,
      to,
      subject: "Your Excuse",
      text: message,
    });

    res.json({ success: true, message: "Email sent successfully" });
  } catch (err) {
    res.json({ success: false, error: err.message });
  }
});

app.listen(3000, () => console.log("Server running on http://localhost:3000"));
