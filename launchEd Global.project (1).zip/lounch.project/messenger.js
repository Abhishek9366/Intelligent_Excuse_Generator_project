const { sendSMS } = require("./smsService");
const { sendEmail } = require("./emailService");
// later: WhatsApp, Telegram, Slack, etc.

async function sendExcuse({ to, channel, subject, message }) {
  switch (channel) {
    case "sms":
      return sendSMS(to, message);
    case "email":
      return sendEmail(to, subject || "Excuse Alert", message);
    case "whatsapp":
      // Twilio WhatsApp integration
      return sendSMS("whatsapp:" + to, message);
    default:
      throw new Error("Unsupported channel: " + channel);
  }
}

module.exports = { sendExcuse };
